<div class="container-fluid bg-dark text-light">
<p class="text-center mb-0 py-3">
©Copyright iDiscuss forum 2020 All rights reserved
</p>
</div>
