<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "meditab";

$conn = mysqli_connect($servername,$username,$password,$database);

?>